from Models.Provider import Provider
from Models.Storage_unit import Storage_unit

# 2. предоставить возможность добавления единицы хранения с указанием всех реквизитов
storage_unit = Storage_unit()
storage_unit.add()

# 4. для указанного адреса банка посчитать количество поставщиков склада, пользующихся услугами этого банка.
provider = Provider()
print(provider.getBank('2004, г. Санкт-Петербург ул. Садовая.74 д. 2'))
