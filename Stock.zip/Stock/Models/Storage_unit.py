# Подчинёный класс - класс в котором обрабатывается информация таблицы Climbers
from Models.Model import Model


class Storage_unit(Model):
    # приватное поле Имя таблицы
    __nameTable = 'storage_unit'
    __data = 'data'
    __supplier_id = 'supplier_id'
    __balance_account = 'balance_account'
    __accompanying_document_code = 'accompanying_document_code'
    __number_accompanying_document = 'number_accompanying_document'
    __material_id = 'material_id'
    __material_account = 'material_account'
    __dimension_id = 'dimension_id'
    __amount_material_received = 'amount_material_received'
    __price_measurement = 'price_measurement'

    # Метод вывода всех записей из таблицы
    def get(self):
        return super().get(self.__nameTable)

    # Метод вывода записей одного поля из таблицы
    def getOneField(self, field):
        return super().getOneField(self.__nameTable, field)

    # Добавить запись в таблицу
    def add(self):
        data = input("Введите дату: ")
        supplier_id = input("Введите id поставщика: ")
        balance_account = input("Введите баланс: ")
        accompanying_document_code = input("Введите id сопроводительного документа: ")
        number_accompanying_document = input("Введите номер сопроводительного документа: ")
        material_id = input("Введите id материала: ")
        material_account = input("Введите материальный счет: ")
        dimension_id = input("Введите id еденицы измерения: ")
        amount_material_received = input("Введите количество полученого материала : ")
        price_measurement = input("Введите измерение цен: ")

        str = (f"{self.__data},{self.__supplier_id},{self.__balance_account},"
               f"{self.__accompanying_document_code},{self.__number_accompanying_document},{self.__material_id},"
               f"{self.__material_account},{self.__dimension_id},{self.__amount_material_received},{self.__price_measurement}")
        super().add(self.__nameTable, str, data, supplier_id, balance_account, accompanying_document_code, number_accompanying_document,
                    material_id, material_account, dimension_id, amount_material_received, price_measurement)

    # Удалить запись из таблицы запись в таблицу
    def delete(self, id):
        super().delete(self.__nameTable, id)

    # Обновить запись в таблице
    def update(self):
        id = input("Введите id, записи, которую хотите изменить")
        field = input("Введите название поля")
        values = input("введите новое значение")
        super().update(self.__nameTable, id, field, values)

    def getLastRow(self):
        return super().getLastRow(self.__nameTable)[0]

    def getOneRow(self, id):
        return super().getOneRow(self.__nameTable, id)

