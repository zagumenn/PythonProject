from Models.Medicines import Medicines
from Models.Visits import Visits

# 1. по заданной дате определить количество вызовов в этот день
visits = Visits()
print(visits.getCountVisits('2023-10-15'))

# 2. позволяют определить количество больных, заболевших данной болезнью
visits = Visits()
print(visits.getCountDiagnosis('Гастрит'))

# 3. по заданному лекарству определить его побочный эффект порядке
medicines = Medicines()
print(medicines.getSideEffects('Аспирин'))

# 4. предоставить возможность добавления нового лекарства с описанием его свойств в БД
medicines = Medicines()
medicines.add()