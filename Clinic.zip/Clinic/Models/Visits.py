# Подчинёный класс - класс в котором обрабатывается информация таблицы Climbers
from Models.Model import Model


class Visits(Model):
    # приватное поле Имя таблицы
    __nameTable = 'clinic'
    __Name_Medicine = 'Name_Medicine'
    __How_to_Use = 'How_to_Use'
    __Drug_Actions = 'Drug_Actions'
    __Side_Effects = 'Side_Effects'

    # Метод вывода всех записей из таблицы
    def get(self):
        return super().get(self.__nameTable)

    # Метод вывода записей одного поля из таблицы
    def getOneField(self, field):
        return super().getOneField(self.__nameTable, field)

    # Добавить запись в таблицу
    def add(self):
        Name_Medicine = input("Введите дату: ")
        How_to_Use = input("Введите id поставщика: ")
        Drug_Actions = input("Введите баланс: ")
        Side_Effects = input("Введите id сопроводительного документа: ")

        str = (f"{self.__Name_Medicine},{self.__How_to_Use},{self.__Drug_Actions},"
               f"{self.__Side_Effects}")
        super().add(self.__nameTable, str, Name_Medicine, How_to_Use, Drug_Actions, Side_Effects)

    # Удалить запись из таблицы запись в таблицу
    def delete(self, id):
        super().delete(self.__nameTable, id)

    # Обновить запись в таблице
    def update(self):
        id = input("Введите id, записи, которую хотите изменить")
        field = input("Введите название поля")
        values = input("введите новое значение")
        super().update(self.__nameTable, id, field, values)

    def getLastRow(self):
        return super().getLastRow(self.__nameTable)[0]

    def getOneRow(self, id):
        return super().getOneRow(self.__nameTable, id)
    
    def getCountVisits(self, Data_P):
        return  super().getCountVisits(Data_P)
    
    def getCountDiagnosis(self, Diagnosis):
        return super().getCountDiagnosis(Diagnosis)
