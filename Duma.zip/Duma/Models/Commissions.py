# Подчинёный класс - класс в котором обрабатывается информация таблицы Climbers
from Models.Model import Model

class Commissions(Model):
    # приватное поле Имя таблицы
    __nameTable = 'commission'
    __Name = 'Name'
    __Chairman = 'Chairman'
    __Date_E = 'Phone_H'
    __Profile = 'Profile'


    # Метод вывода всех записей из таблицы
    def get(self):
        return super().get(self.__nameTable)

    # Метод вывода записей одного поля из таблицы
    def getOneField(self, field):
        return super().getOneField(self.__nameTable, field)

    # Добавить запись в таблицу
    def add(self):
        Name = input("Введите название: ")
        Chairman = input("Введите Председателя: ")
        Date_E = input("Введите дату: ")
        Profile = input("Введите рабочий тему: ")

        str = (f"{self.__Name},{self.__Chairman},{self.__Date_E},{self.__Profile}")
        super().add(self.__nameTable, str, Name, Chairman, Date_E, Profile)

    # Удалить запись из таблицы запись в таблицу
    def delete(self, id):
        super().delete(self.__nameTable, id)

    # Обновить запись в таблице
    def update(self):
        id = input("Введите id, записи, которую хотите изменить")
        field = input("Введите название поля")
        values = input("введите новое значение")
        super().update(self.__nameTable, id, field, values)

    def getLastRow(self):
        return super().getLastRow(self.__nameTable)[0]

    def getOneRow(self, id):
        return super().getOneRow(self.__nameTable, id)

    def getCommissions(self):
        return super().getCommissions()

    def getData(self, start_data, end_data, ID_Commission):
        return super().getData(start_data, end_data, ID_Commission)

    def getCountMeeting(self, start_date, end_date):
        return super().getCountMeeting(start_date, end_date)


