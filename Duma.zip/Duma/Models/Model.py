from Configuration.config import connnection
# Супер класс для таблиц БД
class Model:


    def getCursor(self, query):
        with connnection().cursor() as cursor:
            cursor.execute(query)
            return cursor.fetchall()

    # def get(self, table):
    #     query = f"SELECT * FROM {table}", table
    #     self.myGetCursor()
    # метод вывода данных из таблицы

    def get(self, nametable):
        # query = "SELECT * FROM %s" %nametable
        return self.getCursor("SELECT * FROM %s" %nametable)

    def getOneField(self, table, field):
        with connnection().cursor() as cursor:
            select_one_field = f"SELECT {field} FROM {table}"
            cursor.execute(select_one_field)
            return cursor.fetchall()
        connnection().close()

#       Добавить запись в таблицу
    def add(self, table, str, *values):
        with connnection().cursor() as cursor:
            print(f"INSERT INTO {table} ({str}) VALUES {values}")
            query = f"INSERT INTO {table} ({str}) VALUES {values}"
            cursor.execute(query)
        connnection().close()
        print(f"Новая запись в таблицу {table} добавлена")

#       Удаление записи
    def delete(self,table, id):
        with connnection().cursor() as cursor:
            query_delete = f"DELETE FROM {table} WHERE id = {id}"
            cursor.execute(query_delete)
        connnection().close()
        print("Запись удалена")

    def update(self, table, id, field, values):
        with connnection().cursor() as cursor:
            # print(f"UPDATE {table} set {field} = '{values}' where id = {id} ")
            query_update = f"UPDATE {table} SET {field} = '{values}' WHERE id = {id} "
            cursor.execute(query_update)
            connnection().commit()
        connnection().close()
        print("Запись обновлена")

    def getOneRow(self,table,id):
        with connnection().cursor() as cursor:
            query = f"SELECT * FROM {table} WHERE id = {id}"
            cursor.execute(query)
            return cursor.fetchall()
        connnection().close()

    def getLastRow(self, table):
        with connnection().close() as cursor:
            query = (
                    """SELECT * FROM '%s' 
                    ORDER BY id DESC LIMIT 1"""%table
            )
            return cursor.getCursor(query)

    def getFields(self, nameTable, *fields):
        fields = ','.join(fields)
        print("SELECT %s FROM %s" %(fields,nameTable))
        return self.getCursor("SELECT %s FROM %s" %(fields,nameTable))

    def getTable(self, nameTable):
        with connnection().cursor() as cursor:
            cursor.execute("SELECT * FROM %s", nameTable)
            return cursor.fetchall()
        connnection().close()

    def getOneFields(self, nameTable, fields):
        fields = ''.join(fields)
        with connnection().cursor() as cursor:
            cursor.execute("SELECT %s * FROM %s" %(fields, nameTable))
            return cursor.fetchall()
        connnection().close()

    def getCommissions(self):
        with connnection().cursor() as cursor:
            query = (
                """SELECT
                c.Name, c.Chairman, d.FIO
                FROM
                commissions
                c
                LEFT
                JOIN
                deputies_commissions
                dc
                ON
                c.ID_Commission = dc.ID_Commission
                LEFT
                JOIN
                deputies
                d
                ON
                dc.ID_Deputy = d.ID_Deputy"""
            )
            cursor.execute(query)
            return cursor.fetchall()
        connnection().close()


    def getCountDeputies(self):
        with connnection().cursor() as cursor:
            query = (
                """SELECT d.FIO, c.Name, c.Chairman
                FROM deputies d
                LEFT JOIN deputies_commissions dc ON d.ID_Deputy = dc.ID_Deputy
                LEFT JOIN commissions c ON dc.ID_Commission = c.ID_Commission"""
            )
            cursor.execute(query)
            return cursor.fetchall()
        connnection().close()

    def getData(self, start_data, end_data, ID_Commission):
        with connnection().cursor() as cursor:
            query = (
                """SELECT d.FIO, COUNT(m.ID_Commission)
            AS
            Missed_Meetings
            FROM
            deputies
            d
            LEFT
            JOIN
            deputies_commissions
            dc
            ON
            d.ID_Deputy = dc.ID_Deputy
            LEFT
            JOIN
            meetings
            m
            ON
            dc.ID_Commission = m.ID_Commission
            WHERE
            m.Date_M
            BETWEEN '%s' AND '%s'
            AND
            m.ID_Commission = '%s'
                                GROUP
            BY
            d.FIO""" % (start_data, end_data, ID_Commission)
            )
            cursor.execute(query)
            return cursor.fetchall()
        connnection().close()

    def getCountMeeting(self, start_date, end_date):
        with connnection().cursor() as cursor:
            query = (
                """SELECT c.Name, COUNT(m.ID_Commission)
            AS
            Meeting_Count
            FROM
            commissions
            c
            LEFT
            JOIN
            meetings
            m
            ON
            c.ID_Commission = m.ID_Commission
            WHERE
            m.Date_M
            BETWEEN '%s' AND '%s'
            GROUP
            BY
            c.Name""" % (start_date, end_date)
            )
            cursor.execute(query)
            return cursor.fetchall()
        connnection().close()




