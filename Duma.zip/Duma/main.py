from Models.Commissions import Commissions
from Models.Deputies import Deputies
from Models.Meetings import Meetings

# 1. показать список комиссий, для каждой ее состав и председателя
commissions = Commissions()
print(commissions.getCommissions())

# 2. предоставить возможность добавления нового члена комиссии
deputies = Deputies()
deputies.add()

# 3. показать список членов муниципалитета, для каждого из них список комиссий,
# в которых он участвовал и/или был председателем
deputies = Deputies()
print(deputies.getCountDeputies())

# 4. предоставить возможность добавления новой комиссии, с указанием председателя
commissions = Commissions()
commissions.add()

# 5. для указанного интервала дат и комиссии выдать список её членов с указанием количества пропущенных заседаний;
commissions = Commissions()
print(commissions.getData('2023-01-01', '2023-05-29', '1'))

# 6. предоставить возможность добавления нового заседания, с
# указанием присутствующих
meetings = Meetings()
meetings.add()

# 7. по каждой комиссии показать личество проведенных заседаний в указанный период времени
commissions = Commissions()
print(commissions.getCountMeeting('2023-01-01', '2023-05-28'))



