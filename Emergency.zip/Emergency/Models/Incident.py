# Подчинёный класс - класс в котором обрабатывается информация таблицы Climbers
from Models.Model import Model


class Incident(Model):
    # приватное поле Имя таблицы
    __nameTable = 'incident'
    __application_status = 'application_status'
    __data = 'data'
    __type_incident = 'type_incident'

    # Метод вывода всех записей из таблицы
    def get(self):
        return super().get(self.__nameTable)

    # Метод вывода записей одного поля из таблицы
    def getOneField(self, field):
        return super().getOneField(self.__nameTable, field)

    # Добавить запись в таблицу
    def add(self):
        application_status = input("Введите статус заявки: ")
        data = input("Введите дату: ")
        type_incident = input("Введите тип инцидента: ")


        str = f"{self.__application_status},{self.__data},{self.__type_incident}"
        super().add(self.__nameTable, str, application_status, data, type_incident)

    # Удалить запись из таблицы запись в таблицу
    def delete(self, id):
        super().delete(self.__nameTable, id)

    # Обновить запись в таблице
    def update(self):
        id = input("Введите id, записи, которую хотите изменить")
        field = input("Введите название поля")
        values = input("введите новое значение")
        super().update(self.__nameTable, id, field, values)

    def getLastRow(self):
        return super().getLastRow(self.__nameTable)[0]

    def getOneRow(self, id):
        return super().getOneRow(self.__nameTable, id)

    def getCountIncident(self, one_date, two_date):
        return super().getCountIncident(one_date, two_date)