# Подчинёный класс - класс в котором обрабатывается информация таблицы Climbers
from Models.Model import Model


class Culprits_incident(Model):
    # приватное поле Имя таблицы
    __last_name = 'last_name'
    __name = 'name'
    __number_conviction = 'number_conviction'
    __patronymic = 'patronymic'
    __role_id = 'role_id'

    # Метод вывода всех записей из таблицы
    def get(self):
        return super().get(self.__nameTable)

    # Метод вывода записей одного поля из таблицы
    def getOneField(self, field):
        return super().getOneField(self.__nameTable, field)

    # Добавить запись в таблицу
    def add(self):
        last_name = input("Введите фамилию: ")
        name = input("Введите имя: ")
        number_conviction = input("Введите количество судимостей: ")
        patronymic = input("Введите отчество: ")
        role_id = input("Введите id роли: ")


        str = f"{self.__last_name},{self.__name},{self.__number_conviction},{self.__patronymic},{self.__role_id}"
        super().add(self.__nameTable, str, last_name, name, number_conviction, patronymic, role_id)

    # Удалить запись из таблицы запись в таблицу
    def delete(self, id):
        super().delete(self.__nameTable, id)

    # Обновить запись в таблице
    def update(self):
        id = input("Введите id, записи, которую хотите изменить")
        field = input("Введите название поля")
        values = input("введите новое значение")
        super().update(self.__nameTable, id, field, values)

    def getLastRow(self):
        return super().getLastRow(self.__nameTable)[0]

    def getOneRow(self, id):
        return super().getOneRow(self.__nameTable, id)