from Models.Culprits_incident import Culprits_incident
from Models.Incident import Incident

# 2. рассчитать данные о количестве происшествий в указаный промежуток времени
incident = Incident()
print(incident.getCountIncident('2023-01-01', '2023-12-26'))

# 3. для указанного лица получить количество происшествий, в которых он зарегистрирован
culprits_incident = Culprits_incident()
print(culprits_incident.getCulpritsIncident('Иван', 'Голубев', 'Сергеевич'))

# 4. предоставить возможность добавления и изменения
# информации о происшествиях
incident = Incident()
incident.add()
incident.update()

# 5. предоставить возможность добавления и изменения
# информации о лицах, участвующих в происшествиях
culprits_incident = Culprits_incident()
culprits_incident.add()
culprits_incident.update()


