from Models.Culprits_incident import Culprits_incident
from Models.Incident import Incident

# 4. предоставить возможность добавления и изменения
# информации о происшествиях
incident = Incident()
incident.add()
incident.update()

# 5. предоставить возможность добавления и изменения
# информации о лицах, участвующих в происшествиях
culprits_incident = Culprits_incident()
culprits_incident.add()
culprits_incident.update()
