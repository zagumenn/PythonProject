# Подчинёный класс - класс в котором обрабатывается информация таблицы Climbers
from Models.Model import Model


class Room(Model):
    # приватное поле Имя таблицы
    __nameTable = 'room'
    __CampusID = 'CampusID'
    __RoomNumber = 'RoomNumber'
    __Dimensions = 'Dimensions'
    __height = 'height'
    __length = 'length'
    __Purpose = 'Purpose'
    __RoomType = 'RoomType'
    __CeilingHeight = 'CeilingHeight'
    __DepartmentID = 'DepartmentID'

    # Метод вывода всех записей из таблицы
    def get(self):
        return super().get(self.__nameTable)

    # Метод вывода записей одного поля из таблицы
    def getOneField(self, field):
        return super().getOneField(self.__nameTable, field)

    # Добавить запись в таблицу
    def add(self):
        CampusID = input("Введите id кампуса: ")
        RoomNumber = input("Введите номер комнаты: ")
        height = input("Введите высоту: ")
        length = input("Введите длину: ")
        Dimensions = input("Введите размеры: ")
        Purpose = input("Введите дисциплину: ")
        RoomType = input("Введите тип комнаты: ")
        CeilingHeight = input("Введите высоту потолка: ")
        DepartmentID = input("Введите id: ")

        str = (f"{self.__CampusID},{self.__RoomNumber},{self.__Dimensions},"
               f"{self.__height},{self.__length},{self.__Purpose},{self.__RoomType},{self.__CeilingHeight},{self.__DepartmentID}")
        super().add(self.__nameTable, str, CampusID, RoomNumber, Dimensions, height, length, Purpose, RoomType, CeilingHeight, DepartmentID)

    # Удалить запись из таблицы запись в таблицу
    def delete(self, id):
        super().delete(self.__nameTable, id)

    # Обновить запись в таблице
    def update(self):
        id = input("Введите id, записи, которую хотите изменить")
        field = input("Введите название поля")
        values = input("введите новое значение")
        super().update(self.__nameTable, id, field, values)

    def getLastRow(self):
        return super().getLastRow(self.__nameTable)[0]

    def getOneRow(self, id):
        return super().getOneRow(self.__nameTable, id)

    def getRoom(self):
        return  super().getRoom()

