# Подчинёный класс - класс в котором обрабатывается информация таблицы Climbers
from Models.Model import Model


class Campus(Model):
    # приватное поле Имя таблицы
    __nameTable = 'room'
    __Name = 'Name'
    __Location = ' Location'
    __Floors = 'Floors'

    # Метод вывода всех записей из таблицы
    def get(self):
        return super().get(self.__nameTable)

    # Метод вывода записей одного поля из таблицы
    def getOneField(self, field):
        return super().getOneField(self.__nameTable, field)

    # Добавить запись в таблицу
    def add(self):
        Name = input("Введите Имя: ")
        Location = input("Введите расположение: ")
        Floors = input("Введите этаж: ")


        str = (f"{self.__Name},{self.__Location},{self.__Floors},")
        super().add(self.__nameTable, str, Name, Location, Floors)

    # Удалить запись из таблицы запись в таблицу
    def delete(self, id):
        super().delete(self.__nameTable, id)

    # Обновить запись в таблице
    def update(self):
        id = input("Введите id, записи, которую хотите изменить")
        field = input("Введите название поля")
        values = input("введите новое значение")
        super().update(self.__nameTable, id, field, values)

    def getLastRow(self):
        return super().getLastRow(self.__nameTable)[0]

    def getOneRow(self, id):
        return super().getOneRow(self.__nameTable, id)

    def getCampus(self, CampusID):
        return super().getCampus(CampusID)