from Models.Campus import Campus
from Models.Room import Room

# 1. рассчитать данные о площадях и объемах каждого помещения
room = Room()
print(room.getRoom())


# 2. для указанного корпуса получить количество факультетов, их названия и структуру, находящиеся в этом корпусе;
campus = Campus()
print(campus.getCampus('1'))

# 3. предоставить возможность добавления и изменения информации о корпусах в университете
campus = Campus()
campus.add()
campus.update()

# 4. предоставить возможность добавления и изменения информации о комнатах в корпусах университета
room = Room()
room.add()
room.update()


