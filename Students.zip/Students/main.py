from Models.Curriculum import Curriculum
from Models.Journal import Journal
from Models.Student import Student

# 1. для указанной формы обучения посчитать количество студентов этой формы обучения
student = Student()
print(student.getFormEducation('дневная'))

# 2. для указанной дисциплины получить количество часов и
# формы отчетности по этой дисциплине;предоставить возможность добавления и изменения информации о студентах,
# об учебных планах, о журнале успеваемости
curriculum = Curriculum()
print(curriculum.getCurriculum('Математика'))

student.add()
student.update()

curriculum.add()
curriculum.update()

# 3. предоставить возможность добавления и изменения информации о журнале успеваемости
journal = Journal()
journal.update()