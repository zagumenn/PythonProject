# Подчинёный класс - класс в котором обрабатывается информация таблицы Climbers
from Models.Model import Model


class Journal(Model):
    # приватное поле Имя таблицы
    __nameTable = 'journal'
    __discipline = 'discipline'
    __estimation = 'estimation'
    __student_id = 'student_id'
    __term = 'term'

    # Метод вывода всех записей из таблицы
    def get(self):
        return super().get(self.__nameTable)

    # Метод вывода записей одного поля из таблицы
    def getOneField(self, field):
        return super().getOneField(self.__nameTable, field)

    # Добавить запись в таблицу
    def add(self):
        discipline = input("Введите дисциплину: ")
        estimation = input("Введите оценку: ")
        student_id = input("Введите id тудента: ")
        term = input("Введите семестр: ")

        str = f"{self.__discipline},{self.__estimation},{self.__student_id},{self.__term}"
        super().add(self.__nameTable, str, discipline, estimation, student_id, term)

    # Удалить запись из таблицы запись в таблицу
    def delete(self, id):
        super().delete(self.__nameTable, id)

    # Обновить запись в таблице
    def update(self):
        id = input("Введите id, записи, которую хотите изменить")
        field = input("Введите название поля")
        values = input("введите новое значение")
        super().update(self.__nameTable, id, field, values)

    def getLastRow(self):
        return super().getLastRow(self.__nameTable)[0]

    def getOneRow(self, id):
        return super().getOneRow(self.__nameTable, id)
