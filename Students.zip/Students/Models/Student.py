# Подчинёный класс - класс в котором обрабатывается информация таблицы Climbers
from Models.Model import Model


class Student(Model):
    # приватное поле Имя таблицы
    __nameTable = 'journal'
    __first_name = 'first_name'
    __form_education = 'form_education'
    __last_name = 'last_name'
    __name_group = 'name_group'
    __patronymic = 'patronymic'
    __year_admission = 'year_admission'

    # Метод вывода всех записей из таблицы
    def get(self):
        return super().get(self.__nameTable)

    # Метод вывода записей одного поля из таблицы
    def getOneField(self, field):
        return super().getOneField(self.__nameTable, field)

    # Добавить запись в таблицу
    def add(self):
        first_name = input("Введите Имя: ")
        form_education = input("Введите форму обучения: ")
        last_name = input("Введите фамилию: ")
        name_group = input("Введите название группы: ")
        patronymic = input("Введите отчество: ")
        year_admission = input("Введите год поступления: ")

        str = f"{self.__first_name},{self.__form_education},{self.__last_name},{self.__name_group},{self.__patronymic},{self.__year_admission}"
        super().add(self.__nameTable, str, first_name, form_education, last_name, name_group, patronymic, year_admission)

    # Удалить запись из таблицы запись в таблицу
    def delete(self, id):
        super().delete(self.__nameTable, id)

    # Обновить запись в таблице
    def update(self):
        id = input("Введите id, записи, которую хотите изменить")
        field = input("Введите название поля")
        values = input("введите новое значение")
        super().update(self.__nameTable, id, field, values)

    def getLastRow(self):
        return super().getLastRow(self.__nameTable)[0]

    def getOneRow(self, id):
        return super().getOneRow(self.__nameTable, id)

    def getFormEducation(self, form_education):
        return super().getFormEducation(form_education)
