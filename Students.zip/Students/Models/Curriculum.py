# Подчинёный класс - класс в котором обрабатывается информация таблицы Climbers
from Models.Model import Model


class Curriculum(Model):
    # приватное поле Имя таблицы
    __nameTable = 'journal'
    __discipline = 'discipline '
    __name_specialty = 'name_specialty'
    __number_hours = 'number_hours'
    __reporting_form = 'reporting_form'
    __term = 'term'

    # Метод вывода всех записей из таблицы
    def get(self):
        return super().get(self.__nameTable)

    # Метод вывода записей одного поля из таблицы
    def getOneField(self, field):
        return super().getOneField(self.__nameTable, field)

    # Добавить запись в таблицу
    def add(self):
        discipline = input("Введите Имя: ")
        name_specialty = input("Введите форму обучения: ")
        number_hours = input("Введите фамилию: ")
        reporting_form = input("Введите название группы: ")
        term = input("Введите отчество: ")


        str = f"{self.__discipline},{self.__name_specialty},{self.__number_hours},{self.__reporting_form},{self.__term}"
        super().add(self.__nameTable, str, discipline, name_specialty, number_hours, reporting_form, term)

    # Удалить запись из таблицы запись в таблицу
    def delete(self, id):
        super().delete(self.__nameTable, id)

    # Обновить запись в таблице
    def update(self):
        id = input("Введите id, записи, которую хотите изменить")
        field = input("Введите название поля")
        values = input("введите новое значение")
        super().update(self.__nameTable, id, field, values)

    def getLastRow(self):
        return super().getLastRow(self.__nameTable)[0]

    def getOneRow(self, id):
        return super().getOneRow(self.__nameTable, id)

    def getCurriculum(self, discipline):
        return super().getCurriculum(discipline)
