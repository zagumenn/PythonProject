# Подчинёный класс - класс в котором обрабатывается информация таблицы Climbers
from Models.Model import Model


class Plate(Model):
    # приватное поле Имя таблицы
    __nameTable = 'group'
    __number = 'number'
    __campaign = 'campaign'
    __company_address = 'company_address'
    __wholesale_price = 'wholesale_price'
    __retail_price = 'retail_price'
    __date_issue = 'date_issue'
    __number_copies= 'number_copies'
    __copies_last_year = 'copies_last_year'
    __copies_this_year = 'copies_this_year'
    __unsold_plates = 'unsold_plates'
    # Метод вывода всех записей из таблицы
    def get(self):
        return super().get(self.__nameTable)

    # Метод вывода записей одного поля из таблицы
    def getOneField(self, field):
        return super().getOneField(self.__nameTable, field)

    # Добавить запись в таблицу
    def add(self):
        title = input("Введите название группы: ")
        number = input("Введите номер: ")
        campaign = input("Введите компанию: ")
        company_address = input("Введите адресс компании: ")
        wholesale_price = input("Введите розничную цену: ")
        retail_price = input("Введите оптовую цену: ")
        date_issue = input("Введите дату выпуска: ")
        number_copies = input("Введите число копий: ")
        copies_last_year = input("Введите число копий проданных за прошлый год: ")
        copies_this_year = input("Введите число копий проданных за этот год: ")
        unsold_plates = input("Введите число непроданных пластинок: ")

        str = (f"{self.__title},{self.__number},{self.__campaign},{self.__company_address},{self.__wholesale_price},{self.__retail_price}"
               f"{self.__date_issue},{self.__number_copies},{self.__copies_last_year},{self.__copies_this_year},{self.__unsold_plates}")
        super().add(self.__nameTable, str, title, number, campaign, company_address, wholesale_price,
                    retail_price, date_issue, number_copies, copies_last_year, copies_this_year, unsold_plates)

    # Удалить запись из таблицы запись в таблицу
    def delete(self, id):
        super().delete(self.__nameTable, id)

    # Обновить запись в таблице
    def update(self):
        id = input("Введите id, записи, которую хотите изменить")
        field = input("Введите название поля")
        values = input("введите новое значение")
        super().update(self.__nameTable, id, field, values)

    def getLastRow(self):
        return super().getLastRow(self.__nameTable)[0]

    def getOneRow(self, id):
        return super().getOneRow(self.__nameTable, id)


