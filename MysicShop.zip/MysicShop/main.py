from Models.Group import Group
from Models.Plate import Plate

# 4. предусмотреть изменения данных о компакт-дисках и ввод новых данных;
plate = Plate()
plate.update()
plate.add()

# 5. предусмотреть ввод новых данных об ансамблях.
group = Group()
group.add()
