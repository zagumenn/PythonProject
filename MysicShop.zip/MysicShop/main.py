from Models.Group import Group
from Models.Plate import Plate

# 4. предусмотреть изменения данных о компакт-дисках и ввод новых данных;
#plate = Plate()
#plate.update()
#plate.add()

# 5. предусмотреть ввод новых данных об ансамблях.
#group = Group()
#group.add()

group = Group()
print(group.getTopSeller())

group = Group()
print(group.getPlate('Ленинград'))

group = Group()
print(group.getCountExecutor('Ленинград'))


